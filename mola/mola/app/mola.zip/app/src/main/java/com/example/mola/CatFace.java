package com.example.mola;

public class CatFace {
    private String profile;
    private String time;

    public CatFace(){ }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getProfile() {
        return profile;
    }

    public void setProfile(String profile) {
        this.profile = profile;
    }
}
