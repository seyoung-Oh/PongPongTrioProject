package com.example.mola;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import org.eazegraph.lib.charts.PieChart;
import org.eazegraph.lib.models.PieModel;

public class HomeActivity extends AppCompatActivity {
    Button btn_record;
    Button btn_chart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        FirebaseStorage storage = FirebaseStorage.getInstance("gs://mola-c4bdf.appspot.com");
        StorageReference storageRef = storage.getReference();

        for(int i =1;i<=8;i++) {
            ImageView load;
            final int num = i;
            load = (ImageView) findViewById(getResources().getIdentifier("loadimg_" + num, "id", "com.example.mola"));
            storageRef.child("image_store/catImg_"+num+".jpg").getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                @Override
                public void onSuccess(Uri uri) {
                    System.out.println(num);
                    Glide.with(getApplicationContext())
                            .load(uri)
                            .into(load);

                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception exception) {

                    //이미지 로드 실패시
                    Toast.makeText(getApplicationContext(), "실패", Toast.LENGTH_SHORT).show();
                }
            });
        }

        DatabaseReference database = FirebaseDatabase.getInstance().getReference();
        DatabaseReference rest = database.child("catfood").child("rest").child("num");
        PieChart mPieChart = (PieChart) findViewById(R.id.piechart);
        final int[] chartNum = new int[1];
        rest.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int mynum = snapshot.getValue(Integer.class);
                chartNum[0] = mynum;
//                System.out.println(mynum);
                mPieChart.addPieSlice(new PieModel("최대 급여 횟수", chartNum[0], Color.parseColor("#ffb8b8")));
                mPieChart.addPieSlice(new PieModel("현재까지 먹은 사료", 100-chartNum[0], Color.parseColor("#fff4f4")));

                mPieChart.startAnimation();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });


        btn_record = findViewById(R.id.btn_record);
        btn_record.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),RecordActivity.class);
                startActivity(intent);
            }
        });
        btn_chart = findViewById(R.id.btn_chart);
        btn_chart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),ChartActivity.class);
                startActivity(intent);
            }
        });
    }
}