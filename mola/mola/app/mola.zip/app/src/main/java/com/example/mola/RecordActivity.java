package com.example.mola;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.ListResult;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class RecordActivity extends AppCompatActivity {
//
//    private RecyclerView recyclerView;
//    private RecyclerView.Adapter adapter;
//    private RecyclerView.LayoutManager layoutManager;
//    private ArrayList<CatFace> arrayList;
//    private FirebaseDatabase database;
//    private StorageReference storageReference;
    ArrayList<String> imagelist;
    RecyclerView recyclerView;
    StorageReference root;
//    ProgressBar progressBar;
    ImageAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record);

        imagelist=new ArrayList<String>();
        recyclerView=findViewById(R.id.rv_time);

        adapter=new ImageAdapter(imagelist,this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
//        progressBar=findViewById(R.id.progress);
//        progressBar.setVisibility(View.VISIBLE);
        StorageReference listRef = FirebaseStorage.getInstance("gs://mola-c4bdf.appspot.com").getReference().child("image_store");
        listRef.listAll().addOnSuccessListener(new OnSuccessListener<ListResult>() {
            @Override
            public void onSuccess(ListResult listResult) {
                for(StorageReference file:listResult.getItems()){
                    file.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {

                            imagelist.add(uri.toString());
                            Log.e("Itemvalue",uri.toString());
                            System.out.println("완료1");
                        }
                    }).addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {

                            recyclerView.setAdapter(adapter);
                            System.out.println("완료2");
//                            progressBar.setVisibility(View.GONE);
                        }
                    });
                }
            }
        });
    }
}